// Algorithm Explorer's algorithms and data structures, compiled to WebAssembly.
// The browser handles presentation; all core algorithm work lives in this C++ file.

namespace {
const int kMaxValues = 24;
const int kMaxEvents = 2048;
const int kMaxBenchValues = 100000;
const int kMaxListNodes = 32;

double sortValues[kMaxValues];
double sortInitial[kMaxValues];
double sortSnapshots[kMaxEvents][kMaxValues];
int eventKinds[kMaxEvents];
int eventLeft[kMaxEvents];
int eventRight[kMaxEvents];
int sortLength = 0;
int eventCount = 0;
int comparisons = 0;
int moves = 0;

double benchValues[kMaxBenchValues];
double benchScratch[kMaxBenchValues];
int benchComparisons = 0;
int benchMoves = 0;
unsigned int randomState = 1;

double fibMemo[36];
int fibCalls = 0;
double fibAnswer = 0;
int hanoiFrom[255];
int hanoiTo[255];
int hanoiCount = 0;

double stackValues[12];
int stackCapacity = 6;
int stackLength = 0;

double queueValues[12];
int queueCapacity = 6;
int queueHead = 0;
int queueLength = 0;
int queueIsCircular = 0;

struct Node {
  double value;
  int next;
  int previous;
  int used;
};
Node listNodes[kMaxListNodes];
int listHead = -1;
int listTail = -1;
int listLength = 0;
int listIsDoubly = 0;

char bracketCharacters[120];
int bracketActions[120];
int bracketDepths[120];
char bracketStacks[120][120];
int bracketRows = 0;
int bracketValid = 1;
int bracketErrorIndex = -1;

int recordEvent(int kind, int left, int right) {
  if (eventCount >= kMaxEvents) return 0;
  eventKinds[eventCount] = kind;
  eventLeft[eventCount] = left;
  eventRight[eventCount] = right;
  for (int i = 0; i < sortLength; ++i) {
    sortSnapshots[eventCount][i] = sortValues[i];
  }
  ++eventCount;
  return 1;
}

void swapSortValues(int left, int right) {
  if (left == right) return;
  const double value = sortValues[left];
  sortValues[left] = sortValues[right];
  sortValues[right] = value;
  moves += 3;
  recordEvent(2, left, right);
}

void mergeSort(int begin, int end, double* scratch) {
  if (end - begin < 2) return;
  const int middle = begin + (end - begin) / 2;
  mergeSort(begin, middle, scratch);
  mergeSort(middle, end, scratch);
  int left = begin;
  int right = middle;
  int output = begin;
  while (left < middle && right < end) {
    ++comparisons;
    recordEvent(1, left, right);
    if (sortValues[left] <= sortValues[right]) scratch[output++] = sortValues[left++];
    else scratch[output++] = sortValues[right++];
  }
  while (left < middle) scratch[output++] = sortValues[left++];
  while (right < end) scratch[output++] = sortValues[right++];
  for (int i = begin; i < end; ++i) {
    sortValues[i] = scratch[i];
    ++moves;
    recordEvent(3, i, i);
  }
}

int partitionSort(int begin, int end, int randomized) {
  int pivotIndex = end - 1;
  if (randomized) {
    randomState = randomState * 1664525u + 1013904223u;
    pivotIndex = begin + static_cast<int>(randomState % static_cast<unsigned int>(end - begin));
    swapSortValues(pivotIndex, end - 1);
  }
  const double pivot = sortValues[end - 1];
  int boundary = begin;
  for (int i = begin; i < end - 1; ++i) {
    ++comparisons;
    recordEvent(1, i, end - 1);
    if (sortValues[i] <= pivot) swapSortValues(i, boundary++);
  }
  swapSortValues(boundary, end - 1);
  return boundary;
}

void quickSort(int begin, int end, int randomized) {
  if (begin >= end) return;
  const int pivot = partitionSort(begin, end, randomized);
  quickSort(begin, pivot - 1, randomized);
  quickSort(pivot + 1, end, randomized);
}

double fibonacci(int n, int method) {
  ++fibCalls;
  if (n < 2) return n;
  if (method == 0 && fibMemo[n] >= 0) return fibMemo[n];
  const double answer = fibonacci(n - 1, method) + fibonacci(n - 2, method);
  if (method == 0) fibMemo[n] = answer;
  return answer;
}

double factorialRecursive(int n) {
  ++fibCalls;
  return n < 2 ? 1 : n * factorialRecursive(n - 1);
}

void hanoi(int disks, int source, int destination, int auxiliary) {
  if (disks == 0 || hanoiCount >= 255) return;
  hanoi(disks - 1, source, auxiliary, destination);
  hanoiFrom[hanoiCount] = source;
  hanoiTo[hanoiCount++] = destination;
  hanoi(disks - 1, auxiliary, destination, source);
}

unsigned int nextRandom() {
  randomState = randomState * 1664525u + 1013904223u;
  return randomState;
}

void benchmarkMergeSort(int begin, int end) {
  if (end - begin < 2) return;
  const int middle = begin + (end - begin) / 2;
  benchmarkMergeSort(begin, middle);
  benchmarkMergeSort(middle, end);
  int left = begin;
  int right = middle;
  int output = begin;
  while (left < middle && right < end) {
    ++benchComparisons;
    benchScratch[output++] = benchValues[left] <= benchValues[right]
      ? benchValues[left++] : benchValues[right++];
  }
  while (left < middle) benchScratch[output++] = benchValues[left++];
  while (right < end) benchScratch[output++] = benchValues[right++];
  for (int i = begin; i < end; ++i) benchValues[i] = benchScratch[i];
  benchMoves += end - begin;
}

int benchmarkPartition(int begin, int end) {
  const int selected = begin + static_cast<int>(nextRandom() % static_cast<unsigned int>(end - begin));
  const double pivot = benchValues[selected];
  benchValues[selected] = benchValues[end - 1];
  benchValues[end - 1] = pivot;
  int boundary = begin;
  for (int i = begin; i < end - 1; ++i) {
    ++benchComparisons;
    if (benchValues[i] <= pivot) {
      const double value = benchValues[i];
      benchValues[i] = benchValues[boundary];
      benchValues[boundary++] = value;
      benchMoves += 3;
    }
  }
  const double value = benchValues[boundary];
  benchValues[boundary] = benchValues[end - 1];
  benchValues[end - 1] = value;
  benchMoves += 3;
  return boundary;
}

void benchmarkQuickSort(int begin, int end) {
  if (begin >= end) return;
  const int pivot = benchmarkPartition(begin, end);
  benchmarkQuickSort(begin, pivot - 1);
  benchmarkQuickSort(pivot + 1, end);
}

int allocateNode() {
  for (int i = 0; i < kMaxListNodes; ++i) {
    if (!listNodes[i].used) {
      listNodes[i].used = 1;
      listNodes[i].next = -1;
      listNodes[i].previous = -1;
      return i;
    }
  }
  return -1;
}

int findListNode(double value) {
  int current = listHead;
  while (current >= 0) {
    if (listNodes[current].value == value) return current;
    current = listNodes[current].next;
  }
  return -1;
}

void unlinkNode(int node) {
  const int previous = listNodes[node].previous;
  const int next = listNodes[node].next;
  if (previous >= 0) listNodes[previous].next = next;
  else listHead = next;
  if (next >= 0) listNodes[next].previous = previous;
  else listTail = previous;
  listNodes[node].used = 0;
  --listLength;
}
}

// Runs one of the five sorting algorithms and records a visual snapshot per operation.
// Bubble, selection and insertion are O(n^2); merge is O(n log n); quicksort is
// average O(n log n), worst O(n^2). The visualization accepts at most 24 values.
extern "C" int sort_begin(int length, int algorithm, int randomizedPivot) {
  if (length < 2 || length > kMaxValues || algorithm < 0 || algorithm > 4) return -1;
  sortLength = length;
  eventCount = comparisons = moves = 0;
  for (int i = 0; i < length; ++i) sortInitial[i] = sortValues[i];
  if (algorithm == 0) {
    for (int end = length - 1; end > 0; --end) {
      int changed = 0;
      for (int i = 0; i < end; ++i) {
        ++comparisons;
        recordEvent(1, i, i + 1);
        if (sortValues[i] > sortValues[i + 1]) {
          swapSortValues(i, i + 1);
          changed = 1;
        }
      }
      if (!changed) break;
    }
  } else if (algorithm == 1) {
    for (int i = 0; i < length - 1; ++i) {
      int smallest = i;
      for (int j = i + 1; j < length; ++j) {
        ++comparisons;
        recordEvent(1, smallest, j);
        if (sortValues[j] < sortValues[smallest]) smallest = j;
      }
      swapSortValues(i, smallest);
    }
  } else if (algorithm == 2) {
    for (int i = 1; i < length; ++i) {
      const double value = sortValues[i];
      int j = i;
      while (j > 0) {
        ++comparisons;
        recordEvent(1, j - 1, j);
        if (sortValues[j - 1] <= value) break;
        sortValues[j] = sortValues[j - 1];
        ++moves;
        recordEvent(3, j - 1, j);
        --j;
      }
      sortValues[j] = value;
      ++moves;
      recordEvent(3, j, i);
    }
  } else if (algorithm == 3) {
    double scratch[kMaxValues];
    mergeSort(0, length, scratch);
  } else {
    randomState = 42;
    quickSort(0, length - 1, randomizedPivot);
  }
  return eventCount;
}

extern "C" void sort_input(int index, double value) {
  if (index >= 0 && index < kMaxValues) sortValues[index] = value;
}
extern "C" int sort_steps() { return eventCount; }
extern "C" int sort_length() { return sortLength; }
extern "C" double sort_value_at(int step, int index) {
  if (index < 0 || index >= sortLength) return 0;
  return step < 0 ? sortInitial[index] : sortSnapshots[step][index];
}
extern "C" int sort_step_kind(int step) { return step >= 0 && step < eventCount ? eventKinds[step] : 0; }
extern "C" int sort_step_left(int step) { return step >= 0 && step < eventCount ? eventLeft[step] : -1; }
extern "C" int sort_step_right(int step) { return step >= 0 && step < eventCount ? eventRight[step] : -1; }
extern "C" int sort_comparisons() { return comparisons; }
extern "C" int sort_moves() { return moves; }

// Calculates Fibonacci with memoized recursion, naive recursion or bottom-up DP.
// All methods return the same value; n is restricted to 30 for a safe naive run.
extern "C" double fibonacci_run(int n, int method) {
  if (n < 0 || n > 30 || method < 0 || method > 2) return -1;
  fibCalls = 0;
  for (int i = 0; i < 36; ++i) fibMemo[i] = -1;
  if (method == 2) {
    if (n < 2) return fibAnswer = n;
    double previous = 0;
    double current = 1;
    fibCalls = 2;
    for (int i = 2; i <= n; ++i) {
      const double next = previous + current;
      previous = current;
      current = next;
      ++fibCalls;
    }
    return fibAnswer = current;
  }
  return fibAnswer = fibonacci(n, method);
}
extern "C" int fibonacci_calls() { return fibCalls; }

// Computes n! using recursion or iteration in O(n) time and O(n) / O(1) space.
extern "C" double factorial_run(int n, int recursive) {
  if (n < 0 || n > 170) return -1;
  double answer = 1;
  fibCalls = 0;
  if (recursive) answer = factorialRecursive(n);
  else {
    for (int i = 2; i <= n; ++i) {
      answer *= i;
      ++fibCalls;
    }
  }
  fibAnswer = answer;
  return answer;
}
extern "C" int factorial_calls() { return fibCalls; }

// Generates the recursive Tower of Hanoi move sequence in O(2^n) time.
extern "C" int hanoi_start(int disks) {
  if (disks < 1 || disks > 8) return -1;
  hanoiCount = 0;
  hanoi(disks, 0, 2, 1);
  return hanoiCount;
}
extern "C" int hanoi_move_count() { return hanoiCount; }
extern "C" int hanoi_move_from(int index) { return index >= 0 && index < hanoiCount ? hanoiFrom[index] : -1; }
extern "C" int hanoi_move_to(int index) { return index >= 0 && index < hanoiCount ? hanoiTo[index] : -1; }

// Stack operations use a fixed-size array; push and peek are O(1), pop is O(1).
extern "C" int stack_set_capacity(int capacity) {
  if (capacity < 1 || capacity > 12 || capacity < stackLength) return 0;
  stackCapacity = capacity;
  return 1;
}
extern "C" int stack_push(double value) {
  if (stackLength == stackCapacity) return 0;
  stackValues[stackLength++] = value;
  return 1;
}
extern "C" int stack_pop() { if (stackLength == 0) return 0; --stackLength; return 1; }
extern "C" int stack_peek(double* value) {
  if (stackLength == 0) return 0;
  *value = stackValues[stackLength - 1];
  return 1;
}
extern "C" int stack_size() { return stackLength; }
extern "C" int stack_capacity() { return stackCapacity; }
extern "C" double stack_value_at(int index) {
  return index >= 0 && index < stackLength ? stackValues[index] : 0;
}

// Queue operations use circular indexing for O(1) enqueue and dequeue.
extern "C" int queue_set_capacity(int capacity) {
  if (capacity < 1 || capacity > 12 || capacity < queueLength) return 0;
  double ordered[12];
  for (int i = 0; i < queueLength; ++i) {
    ordered[i] = queueValues[(queueHead + i) % queueCapacity];
  }
  queueCapacity = capacity;
  queueHead = 0;
  for (int i = 0; i < queueLength; ++i) queueValues[i] = ordered[i];
  return 1;
}
extern "C" void queue_set_circular(int circular) { queueIsCircular = circular != 0; }
extern "C" int queue_enqueue(double value) {
  if (queueLength == queueCapacity) return 0;
  const int index = (queueHead + queueLength) % queueCapacity;
  queueValues[index] = value;
  ++queueLength;
  return 1;
}
extern "C" int queue_dequeue() {
  if (queueLength == 0) return 0;
  if (queueIsCircular) queueHead = (queueHead + 1) % queueCapacity;
  else {
    for (int i = 1; i < queueLength; ++i) queueValues[i - 1] = queueValues[i];
    queueHead = 0;
  }
  --queueLength;
  return 1;
}
extern "C" int queue_size() { return queueLength; }
extern "C" int queue_capacity() { return queueCapacity; }
extern "C" double queue_value_at(int index) {
  return index >= 0 && index < queueLength ? queueValues[(queueHead + index) % queueCapacity] : 0;
}

// Own-node singly/doubly linked list operations; each search is O(n), edits O(1).
extern "C" void list_set_doubly(int doubly) { listIsDoubly = doubly != 0; }
extern "C" int list_add(double value, int atFront) {
  const int node = allocateNode();
  if (node < 0) return 0;
  listNodes[node].value = value;
  if (listLength == 0) listHead = listTail = node;
  else if (atFront) {
    listNodes[node].next = listHead;
    if (listIsDoubly) listNodes[listHead].previous = node;
    listHead = node;
  } else {
    listNodes[node].previous = listTail;
    listNodes[listTail].next = node;
    listTail = node;
  }
  ++listLength;
  return 1;
}
extern "C" int list_insert(double value, double reference, int before) {
  const int target = findListNode(reference);
  if (target < 0) return 0;
  const int node = allocateNode();
  if (node < 0) return -1;
  listNodes[node].value = value;
  const int left = before ? listNodes[target].previous : target;
  const int right = before ? target : listNodes[target].next;
  listNodes[node].previous = left;
  listNodes[node].next = right;
  if (left >= 0) listNodes[left].next = node;
  else listHead = node;
  if (right >= 0) listNodes[right].previous = node;
  else listTail = node;
  ++listLength;
  return 1;
}
extern "C" int list_remove(double value, int mode) {
  if (listLength == 0) return 0;
  int node = mode == 0 ? listHead : mode == 1 ? listTail : findListNode(value);
  if (node < 0) return 0;
  unlinkNode(node);
  return 1;
}
extern "C" int list_search(double value) { return findListNode(value) >= 0; }
extern "C" int list_size() { return listLength; }
extern "C" double list_value_at(int index) {
  if (index < 0 || index >= listLength) return 0;
  int node = listHead;
  for (int i = 0; i < index; ++i) node = listNodes[node].next;
  return listNodes[node].value;
}
extern "C" int list_is_doubly() { return listIsDoubly; }

// Checks balanced brackets with an explicit stack and preserves a row-by-row trace.
// The scan is O(n) time and O(n) extra space.
extern "C" int brackets_check(const char* text, int length) {
  char stack[120];
  int depth = 0;
  bracketRows = 0;
  bracketValid = 1;
  bracketErrorIndex = -1;
  for (int i = 0; i < length && i < 120; ++i) {
    const char symbol = text[i];
    if (symbol != '(' && symbol != ')' && symbol != '[' && symbol != ']' &&
        symbol != '{' && symbol != '}') continue;
    int action = 0;
    if (symbol == '(' || symbol == '[' || symbol == '{') {
      stack[depth++] = symbol;
      action = 1;
    } else if (depth > 0 &&
               ((symbol == ')' && stack[depth - 1] == '(') ||
                (symbol == ']' && stack[depth - 1] == '[') ||
                (symbol == '}' && stack[depth - 1] == '{'))) {
      --depth;
      action = 2;
    } else {
      action = 3;
      bracketValid = 0;
      bracketErrorIndex = i;
    }
    bracketCharacters[bracketRows] = symbol;
    bracketActions[bracketRows] = action;
    bracketDepths[bracketRows] = depth;
    for (int j = 0; j < depth; ++j) bracketStacks[bracketRows][j] = stack[j];
    ++bracketRows;
    if (!bracketValid) break;
  }
  if (bracketValid && depth != 0) {
    bracketValid = 0;
    bracketErrorIndex = length;
  }
  return bracketValid;
}
extern "C" int brackets_rows() { return bracketRows; }
extern "C" int brackets_valid() { return bracketValid; }
extern "C" int brackets_error_index() { return bracketErrorIndex; }
extern "C" int brackets_character(int row) { return row >= 0 && row < bracketRows ? bracketCharacters[row] : 0; }
extern "C" int brackets_action(int row) { return row >= 0 && row < bracketRows ? bracketActions[row] : 0; }
extern "C" int brackets_depth(int row) { return row >= 0 && row < bracketRows ? bracketDepths[row] : 0; }
extern "C" int brackets_stack_at(int row, int index) {
  return row >= 0 && row < bracketRows && index >= 0 && index < bracketDepths[row]
    ? bracketStacks[row][index] : 0;
}

// Runs a selected sort on up to 100,000 generated values for complexity experiments.
// Sorting operations remain first-principles implementations from this source file.
extern "C" int benchmark_run(int length, int algorithm, int order, unsigned int seed) {
  if (length < 2 || length > kMaxBenchValues || algorithm < 0 || algorithm > 4 ||
      order < 0 || order > 2) return 0;
  benchComparisons = benchMoves = 0;
  randomState = seed ? seed : 1;
  for (int i = 0; i < length; ++i) {
    const double value = static_cast<double>(nextRandom() % 100000u);
    benchValues[i] = order == 1 ? static_cast<double>(i)
      : order == 2 ? static_cast<double>(length - i) : value;
  }
  if (algorithm == 3) benchmarkMergeSort(0, length);
  else if (algorithm == 4) benchmarkQuickSort(0, length - 1);
  else if (algorithm == 0) {
    for (int end = length - 1; end > 0; --end) {
      int changed = 0;
      for (int i = 0; i < end; ++i) {
        ++benchComparisons;
        if (benchValues[i] > benchValues[i + 1]) {
          const double value = benchValues[i];
          benchValues[i] = benchValues[i + 1];
          benchValues[i + 1] = value;
          benchMoves += 3;
          changed = 1;
        }
      }
      if (!changed) break;
    }
  } else if (algorithm == 1) {
    for (int i = 0; i < length - 1; ++i) {
      int smallest = i;
      for (int j = i + 1; j < length; ++j) {
        ++benchComparisons;
        if (benchValues[j] < benchValues[smallest]) smallest = j;
      }
      if (smallest != i) {
        const double value = benchValues[i];
        benchValues[i] = benchValues[smallest];
        benchValues[smallest] = value;
        benchMoves += 3;
      }
    }
  } else {
    for (int i = 1; i < length; ++i) {
      const double value = benchValues[i];
      int j = i;
      while (j > 0) {
        ++benchComparisons;
        if (benchValues[j - 1] <= value) break;
        benchValues[j] = benchValues[j - 1];
        --j;
        ++benchMoves;
      }
      benchValues[j] = value;
      ++benchMoves;
    }
  }
  return 1;
}
extern "C" int benchmark_comparisons() { return benchComparisons; }
extern "C" int benchmark_moves() { return benchMoves; }
