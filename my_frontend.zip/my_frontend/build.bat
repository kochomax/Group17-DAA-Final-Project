@echo off
setlocal
cd /d "%~dp0"

set "CLANG=C:\Program Files\LLVM\bin\clang++.exe"
if not exist "%CLANG%" set "CLANG=clang++"

echo Building the C++ algorithm engine for WebAssembly...
"%CLANG%" --target=wasm32-unknown-unknown -nostdlib -Wl,--no-entry -Wl,--export-all -Wl,--allow-undefined -Wl,--export-memory -Wl,--initial-memory=16777216 -Wl,--max-memory=33554432 -fno-exceptions -fno-rtti -O2 algorithms.cpp -o algorithm-explorer.wasm
if errorlevel 1 (
  echo C++ WebAssembly build failed. Install LLVM with WebAssembly target support and try again.
  exit /b 1
)

echo Building the local C++ web server...
g++ -std=c++17 server.cpp -lws2_32 -o AlgorithmExplorerServer.exe
if errorlevel 1 (
  echo C++ web server build failed. Install a Windows C++ compiler and try again.
  exit /b 1
)

echo Build complete.
