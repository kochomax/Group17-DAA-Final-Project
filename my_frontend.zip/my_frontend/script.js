"use strict";

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => Array.from(document.querySelectorAll(selector));
let engine = null;
let sortLength = 0;
let sortStepIndex = -1;
let sortTimer = 0;
let hanoiDisks = 0;
let hanoiMoves = 0;
let hanoiStep = 0;
let hanoiPegs = [[], [], []];
let hanoiTimer = 0;
let toastTimer = 0;

const pageNames = {
  overview: "Overview",
  recursion: "Recursion lab",
  structures: "Data structures",
  sorting: "Sorting lab",
  analysis: "Time analysis"
};
const algorithmNames = ["Bubble sort", "Selection sort", "Insertion sort", "Merge sort", "Quick sort"];

function showFeedback(id, message) {
  const element = document.getElementById(id);
  if (!element) return;
  element.textContent = message;
  element.hidden = false;
}

function clearFeedback(id) {
  const element = document.getElementById(id);
  if (element) element.hidden = true;
}

function notify(message) {
  const region = $("#toastRegion");
  const toast = document.createElement("div");
  toast.className = "toast";
  toast.textContent = message;
  region.replaceChildren(toast);
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => toast.remove(), 3000);
}

function requireEngine() {
  if (!engine) {
    notify("The C++ engine is still loading. Please try again in a moment.");
    return false;
  }
  return true;
}

function setPage(name) {
  if (!pageNames[name]) return;
  $$(".page-section").forEach((section) => {
    const active = section.id === `page-${name}`;
    section.classList.toggle("active", active);
    section.hidden = !active;
  });
  $$("[data-page]").forEach((button) => {
    const active = button.dataset.page === name;
    button.classList.toggle("active", active);
    if (active && button.matches(".nav-link")) button.setAttribute("aria-current", "page");
    else button.removeAttribute("aria-current");
  });
  $("#currentPage").textContent = pageNames[name];
  if (name === "structures") renderAllStructures();
}

document.addEventListener("click", (event) => {
  const pageButton = event.target.closest("[data-page]");
  if (pageButton) {
    event.preventDefault();
    setPage(pageButton.dataset.page);
    return;
  }

  const recursionTab = event.target.closest("[data-rec-tab]");
  if (recursionTab) {
    const selected = recursionTab.dataset.recTab;
    $$("[data-rec-tab]").forEach((tab) => {
      const active = tab === recursionTab;
      tab.classList.toggle("active", active);
      tab.setAttribute("aria-selected", String(active));
    });
    $$(".tab-content[id^='rec-']").forEach((panel) => {
      const active = panel.id === `rec-${selected}`;
      panel.classList.toggle("active", active);
      panel.hidden = !active;
    });
    return;
  }

  const structureTab = event.target.closest("[data-ds-tab]");
  if (structureTab) {
    const selected = structureTab.dataset.dsTab;
    $$("[data-ds-tab]").forEach((tab) => {
      const active = tab === structureTab;
      tab.classList.toggle("active", active);
      tab.setAttribute("aria-selected", String(active));
    });
    $$(".tab-content[id^='ds-']").forEach((panel) => {
      const active = panel.id === `ds-${selected}`;
      panel.classList.toggle("active", active);
      panel.hidden = !active;
    });
    renderAllStructures();
    return;
  }

  const queueType = event.target.closest("[data-queue-type]");
  if (queueType && requireEngine()) {
    $$("[data-queue-type]").forEach((button) => button.classList.toggle("active", button === queueType));
    engine.queue_set_circular(Number(queueType.dataset.queueType));
    $("#queueVisualTitle").textContent = Number(queueType.dataset.queueType) ? "Circular queue" : "Linear queue";
    renderQueue();
    return;
  }

  const listType = event.target.closest("[data-list-type]");
  if (listType && requireEngine()) {
    $$("[data-list-type]").forEach((button) => button.classList.toggle("active", button === listType));
    engine.list_set_doubly(Number(listType.dataset.listType));
    renderList();
    return;
  }

  const listAction = event.target.closest("[data-list-action]");
  if (listAction) handleListAction(listAction.dataset.listAction);
});

async function loadEngine() {
  const status = $("#engineStatus");
  try {
    const response = await fetch("algorithm-explorer.wasm", { cache: "no-store" });
    if (!response.ok) throw new Error(`Could not load the C++ engine (${response.status}).`);
    const result = await WebAssembly.instantiate(await response.arrayBuffer(), {});
    engine = result.instance.exports;
    status.classList.add("ready");
    status.innerHTML = "<i></i> C++ engine ready";
    renderAllStructures();
  } catch (error) {
    status.classList.add("error");
    status.innerHTML = "<i></i> C++ engine unavailable";
    notify(`${error.message} Run build.bat to build the WebAssembly module, then restart the server.`);
    console.error(error);
  }
}

function parseNumberField(id, label) {
  const value = Number(document.getElementById(id).value);
  if (!Number.isFinite(value)) throw new Error(`Enter a valid ${label}.`);
  return value;
}

function formatNumber(value) {
  if (!Number.isFinite(value)) return "—";
  if (Number.isInteger(value)) return value.toLocaleString();
  return value.toLocaleString(undefined, { maximumFractionDigits: 3 });
}

function formatDuration(milliseconds) {
  if (milliseconds < 1) return `${(milliseconds * 1000).toFixed(1)} µs`;
  if (milliseconds < 1000) return `${milliseconds.toFixed(3)} ms`;
  return `${(milliseconds / 1000).toFixed(2)} s`;
}

function setWelcomeMessage() {
  const date = new Date();
  const hour = date.getHours();
  const greeting = hour < 12 ? "GOOD MORNING" : hour < 18 ? "GOOD AFTERNOON" : "GOOD EVENING";
  $("#welcomeGreeting").textContent = greeting;
  const dateElement = $("#welcomeDate");
  dateElement.textContent = `Today · ${date.toLocaleDateString(undefined, {
    weekday: "short",
    month: "short",
    day: "numeric",
    year: "numeric"
  })}`;
  const localDate = [
    date.getFullYear(),
    String(date.getMonth() + 1).padStart(2, "0"),
    String(date.getDate()).padStart(2, "0")
  ].join("-");
  dateElement.dateTime = localDate;
}

setWelcomeMessage();
window.addEventListener("focus", setWelcomeMessage);
document.addEventListener("visibilitychange", () => {
  if (!document.hidden) setWelcomeMessage();
});

function stopSortPlayback() {
  window.clearInterval(sortTimer);
  sortTimer = 0;
  $("#playSort").textContent = "▶ Auto-play";
}

function startSort() {
  if (!requireEngine()) return;
  clearFeedback("sortError");
  stopSortPlayback();
  let values;
  try {
    values = $("#sortInput").value.split(",").map((part) => {
      if (!part.trim()) throw new Error("Separate each number with a comma; empty values are not allowed.");
      const value = Number(part.trim());
      if (!Number.isFinite(value) || Math.abs(value) > 1000000) {
        throw new Error("Enter finite numbers between −1,000,000 and 1,000,000.");
      }
      return value;
    });
  } catch (error) {
    showFeedback("sortError", error.message);
    return;
  }
  if (values.length < 2 || values.length > 24) {
    showFeedback("sortError", "Enter between 2 and 24 numbers.");
    return;
  }

  sortLength = values.length;
  const algorithm = Number($("#sortAlgorithm").value);
  const pivot = Number($("#pivotStrategy").value);
  values.forEach((value, index) => engine.sort_input(index, value));
  const started = performance.now();
  const steps = engine.sort_begin(values.length, algorithm, pivot);
  const elapsed = performance.now() - started;
  if (steps < 0) {
    showFeedback("sortError", "The C++ engine rejected these sorting settings.");
    return;
  }
  sortStepIndex = -1;
  $("#sortComparisons").textContent = formatNumber(engine.sort_comparisons());
  $("#sortMoves").textContent = formatNumber(engine.sort_moves());
  $("#sortTime").textContent = formatDuration(elapsed);
  $("#stepCount").textContent = `${formatNumber(steps)} recorded operations`;
  $("#stepSort").disabled = steps === 0;
  $("#playSort").disabled = steps === 0;
  $("#resetSort").disabled = false;
  $("#sortStatus").textContent = `${algorithmNames[algorithm]} · ${values.length} values`;
  buildStepLog(steps, algorithm);
  renderSortStep();
}

function buildStepLog(steps, algorithm) {
  const log = $("#stepLog");
  log.replaceChildren();
  for (let i = 0; i < steps; i += 1) {
    const row = document.createElement("li");
    const index = document.createElement("span");
    index.className = "log-index";
    index.textContent = String(i + 1).padStart(2, "0");
    const label = document.createElement("span");
    label.textContent = describeSortStep(i, algorithm);
    row.append(index, label);
    log.append(row);
  }
  if (!steps) {
    const empty = document.createElement("li");
    empty.className = "log-empty";
    empty.textContent = "The input is already sorted.";
    log.append(empty);
  }
}

function describeSortStep(index, algorithm) {
  const left = engine.sort_step_left(index);
  const right = engine.sort_step_right(index);
  const kind = engine.sort_step_kind(index);
  const leftValue = formatNumber(engine.sort_value_at(index, left));
  const rightValue = formatNumber(engine.sort_value_at(index, right));
  if (kind === 1) return `Compare ${leftValue} and ${rightValue}`;
  if (kind === 2) return `Swap the values at positions ${left + 1} and ${right + 1}`;
  if (kind === 3) return algorithm === 2 ? `Move value to position ${right + 1}` : `Write ${leftValue} at position ${left + 1}`;
  return "Update the array";
}

function renderSortStep() {
  if (!engine || !sortLength) return;
  const steps = engine.sort_steps();
  const values = Array.from({ length: sortLength }, (_, index) => engine.sort_value_at(sortStepIndex, index));
  const largest = Math.max(1, ...values.map((value) => Math.abs(value)));
  const chart = $("#sortChart");
  chart.replaceChildren();
  const last = sortStepIndex === steps - 1 && steps > 0;
  const left = sortStepIndex < 0 ? -1 : engine.sort_step_left(sortStepIndex);
  const right = sortStepIndex < 0 ? -1 : engine.sort_step_right(sortStepIndex);
  const kind = sortStepIndex < 0 ? 0 : engine.sort_step_kind(sortStepIndex);
  values.forEach((value, index) => {
    const bar = document.createElement("div");
    bar.className = "sort-bar";
    if (last) bar.classList.add("sorted");
    else if (index === left || index === right) bar.classList.add(kind === 1 ? "compare" : "move");
    bar.style.height = `${Math.max(14, (Math.abs(value) / largest) * 142)}px`;
    bar.setAttribute("aria-label", `Index ${index + 1}, value ${value}`);
    const label = document.createElement("b");
    label.textContent = formatNumber(value);
    bar.append(label);
    chart.append(bar);
  });
  const stepText = sortStepIndex < 0 ? "Initial array" : `Step ${sortStepIndex + 1}: ${describeSortStep(sortStepIndex, Number($("#sortAlgorithm").value))}`;
  $("#stepCaption").textContent = last ? "Sort complete — every value is in order." : stepText;
  $("#visualCounter").textContent = steps ? `${Math.max(0, sortStepIndex + 1)} / ${steps}` : "Complete";
  $("#sortStepMetric").textContent = `${Math.max(0, sortStepIndex + 1)} / ${steps}`;
  $("#sortStatus").textContent = last ? "All values sorted." : "Follow the highlighted values through each operation.";
  $("#stepSort").disabled = steps === 0 || sortStepIndex >= steps - 1;
  $("#playSort").disabled = steps === 0 || sortStepIndex >= steps - 1;
  const activeLog = $("#stepLog").children[sortStepIndex];
  $$("#stepLog li").forEach((row) => row.classList.remove("current"));
  if (activeLog) {
    activeLog.classList.add("current");
    activeLog.scrollIntoView({ block: "nearest" });
  }
  if (last) stopSortPlayback();
}

$("#startSort").addEventListener("click", startSort);
$("#sortAlgorithm").addEventListener("change", () => {
  $("#pivotField").hidden = Number($("#sortAlgorithm").value) !== 4;
});
$("#generateArray").addEventListener("click", () => {
  const count = Number($("#randomCount").value);
  if (!Number.isInteger(count) || count < 2 || count > 24) {
    showFeedback("sortError", "Choose between 2 and 24 random values.");
    return;
  }
  clearFeedback("sortError");
  $("#sortInput").value = Array.from({ length: count }, () => Math.floor(Math.random() * 90) + 10).join(", ");
});
$("#stepSort").addEventListener("click", () => {
  if (!engine || sortStepIndex >= engine.sort_steps() - 1) return;
  sortStepIndex += 1;
  renderSortStep();
});
$("#resetSort").addEventListener("click", () => {
  stopSortPlayback();
  sortStepIndex = -1;
  renderSortStep();
});
$("#playSort").addEventListener("click", () => {
  if (sortTimer) {
    stopSortPlayback();
    return;
  }
  $("#playSort").textContent = "Ⅱ Pause";
  sortTimer = window.setInterval(() => {
    if (!engine || sortStepIndex >= engine.sort_steps() - 1) {
      stopSortPlayback();
      return;
    }
    sortStepIndex += 1;
    renderSortStep();
  }, 360);
});

const recursionMethods = ["Memoized recursion", "Naive recursion", "Bottom-up dynamic programming"];
$("#runFib").addEventListener("click", () => {
  if (!requireEngine()) return;
  clearFeedback("fibError");
  const n = Number($("#fibInput").value);
  const method = Number($("#fibMethod").value);
  if (!Number.isInteger(n) || n < 0 || n > 30) {
    showFeedback("fibError", "Enter a whole number from 0 to 30. Naive recursion is intentionally capped for safety.");
    return;
  }
  const started = performance.now();
  const value = engine.fibonacci_run(n, method);
  const elapsed = performance.now() - started;
  $("#fibResult").textContent = formatNumber(value);
  $("#fibMethodLabel").textContent = recursionMethods[method];
  $("#fibCalls").textContent = formatNumber(engine.fibonacci_calls());
  $("#fibTime").textContent = formatDuration(elapsed);
  renderFibMap(n, method);
});
function renderFibMap(n, method) {
  const map = $("#fibTree");
  map.replaceChildren();
  const count = method === 1 ? Math.min(n + 1, 9) : Math.min(n, 8);
  const labels = method === 1
    ? Array.from({ length: count }, (_, index) => `f(${n - index})`).reverse()
    : method === 2
      ? Array.from({ length: count }, (_, index) => index === 0 ? "f(0)" : `f(${index})`)
      : Array.from({ length: count }, (_, index) => index === 0 ? `f(${n})` : `f(${Math.max(0, n - index)})`);
  labels.forEach((label, index) => {
    const node = document.createElement("span");
    node.className = `recursion-node${index === 0 ? " call-main" : ""}`;
    node.textContent = label;
    map.append(node);
  });
}
$("#runFact").addEventListener("click", () => {
  if (!requireEngine()) return;
  clearFeedback("factError");
  const n = Number($("#factInput").value);
  const recursive = Number($("#factMethod").value);
  if (!Number.isInteger(n) || n < 0 || n > 170) {
    showFeedback("factError", "Enter a whole number from 0 to 170.");
    return;
  }
  const started = performance.now();
  const value = engine.factorial_run(n, recursive);
  const elapsed = performance.now() - started;
  $("#factResult").textContent = String(value);
  $("#factMethodLabel").textContent = recursive ? "Recursive" : "Iterative";
  $("#factCalls").textContent = formatNumber(engine.factorial_calls());
  $("#factTime").textContent = formatDuration(elapsed);
  renderFactorialMap(n, recursive);
});
function renderFactorialMap(n, recursive) {
  const map = $("#factTrace");
  map.replaceChildren();
  const shown = Math.min(n, 9);
  const values = recursive
    ? Array.from({ length: shown + 1 }, (_, index) => n - index).filter((value) => value >= 0)
    : Array.from({ length: shown }, (_, index) => index + 1);
  values.forEach((value) => {
    const step = document.createElement("span");
    step.className = "factorial-step";
    step.textContent = recursive ? `n=${value}` : `×${value}`;
    map.append(step);
  });
  if (n === 0) {
    const step = document.createElement("span");
    step.className = "factorial-step";
    step.textContent = "base 1";
    map.append(step);
  }
}

function renderHanoi() {
  const area = $("#towerArea");
  area.replaceChildren();
  hanoiPegs.forEach((peg, pegIndex) => {
    const tower = document.createElement("div");
    tower.className = "tower-peg";
    peg.forEach((disk) => {
      const element = document.createElement("div");
      element.className = "disk";
      element.style.width = `${30 + (hanoiDisks - disk) * 15}px`;
      element.setAttribute("aria-label", `${disk} disk${disk === 1 ? "" : "s"}`);
      tower.append(element);
    });
    const label = document.createElement("span");
    label.className = "tower-label";
    label.textContent = `PEG ${"ABC"[pegIndex]}`;
    tower.append(label);
    area.append(tower);
  });
  $("#hanoiMoveCount").textContent = formatNumber(hanoiStep);
  $("#hanoiMoveTotal").textContent = `of ${hanoiMoves}`;
  $("#hanoiStepLabel").textContent = `${hanoiStep} / ${hanoiMoves}`;
  $("#stepHanoi").disabled = !hanoiMoves || hanoiStep >= hanoiMoves;
  $("#playHanoi").disabled = !hanoiMoves || hanoiStep >= hanoiMoves;
  $("#resetHanoi").disabled = !hanoiMoves;
  $("#hanoiStatus").textContent = hanoiStep === hanoiMoves && hanoiMoves ? "Complete" : hanoiMoves ? "In progress" : "Ready";
}

function stopHanoiPlayback() {
  window.clearInterval(hanoiTimer);
  hanoiTimer = 0;
  $("#playHanoi").textContent = "▶ Auto-play";
}

function advanceHanoi() {
  if (!engine || hanoiStep >= hanoiMoves) return;
  const source = engine.hanoi_move_from(hanoiStep);
  const destination = engine.hanoi_move_to(hanoiStep);
  const disk = hanoiPegs[source].pop();
  if (disk === undefined) {
    stopHanoiPlayback();
    showFeedback("hanoiError", "The move sequence could not be applied to this puzzle.");
    return;
  }
  hanoiPegs[destination].push(disk);
  hanoiStep += 1;
  $("#lastHanoiMove").textContent = `Move disk ${disk} from peg ${"ABC"[source]} to peg ${"ABC"[destination]}.`;
  renderHanoi();
  if (hanoiStep === hanoiMoves) stopHanoiPlayback();
}

$("#startHanoi").addEventListener("click", () => {
  if (!requireEngine()) return;
  clearFeedback("hanoiError");
  stopHanoiPlayback();
  const disks = Number($("#hanoiDisks").value);
  if (!Number.isInteger(disks) || disks < 1 || disks > 8) {
    showFeedback("hanoiError", "Choose between 1 and 8 disks.");
    return;
  }
  hanoiDisks = disks;
  hanoiMoves = engine.hanoi_start(disks);
  hanoiStep = 0;
  hanoiPegs = [Array.from({ length: disks }, (_, index) => disks - index), [], []];
  $("#lastHanoiMove").textContent = "Puzzle ready. Step through the recursive solution.";
  renderHanoi();
});
$("#stepHanoi").addEventListener("click", advanceHanoi);
$("#playHanoi").addEventListener("click", () => {
  if (hanoiTimer) {
    stopHanoiPlayback();
    return;
  }
  $("#playHanoi").textContent = "Ⅱ Pause";
  hanoiTimer = window.setInterval(advanceHanoi, Number($("#hanoiSpeed").value));
});
$("#resetHanoi").addEventListener("click", () => {
  if (!hanoiMoves) return;
  stopHanoiPlayback();
  hanoiStep = 0;
  hanoiPegs = [Array.from({ length: hanoiDisks }, (_, index) => hanoiDisks - index), [], []];
  $("#lastHanoiMove").textContent = "Puzzle reset. Step through the solution.";
  renderHanoi();
});

function setMessage(id, message, error = false) {
  const element = document.getElementById(id);
  if (!element) return;
  element.textContent = message;
  element.hidden = false;
  element.classList.toggle("message-error", error);
}

function renderStack() {
  const size = engine.stack_size();
  const capacity = engine.stack_capacity();
  const visual = $("#stackVisual");
  visual.replaceChildren();
  for (let i = size - 1; i >= 0; i -= 1) {
    const item = document.createElement("div");
    item.className = "structure-item";
    if (i === size - 1) item.classList.add("is-top");
    item.textContent = formatNumber(engine.stack_value_at(i));
    item.setAttribute("aria-label", `${i === size - 1 ? "Top: " : ""}${engine.stack_value_at(i)}`);
    visual.append(item);
  }
  if (!size) visual.innerHTML = '<div class="empty-structure">Your stack is empty.</div>';
  $("#stackSummary").textContent = `${size} item${size === 1 ? "" : "s"} · ${size ? `${capacity - size} spaces available` : "empty"}`;
  $("#stackCapacityLabel").textContent = capacity;
  $("#stackCapacityInput").value = capacity;
}
$("#setStackCapacity").addEventListener("click", () => {
  if (!requireEngine()) return;
  const capacity = Number($("#stackCapacityInput").value);
  if (!Number.isInteger(capacity) || !engine.stack_set_capacity(capacity)) {
    setMessage("stackMessage", "Capacity must be 1–12 and cannot be less than the current number of items.", true);
    return;
  }
  setMessage("stackMessage", `Stack capacity set to ${capacity}.`);
  renderStack();
});
$("#stackPush").addEventListener("click", () => {
  if (!requireEngine()) return;
  const value = Number($("#stackValue").value);
  if ($("#stackValue").value.trim() === "" || !Number.isFinite(value)) {
    setMessage("stackMessage", "Enter a valid number to push.", true);
  } else if (!engine.stack_push(value)) {
    setMessage("stackMessage", "The stack is full. Increase its capacity before pushing another value.", true);
  } else {
    $("#stackValue").value = "";
    setMessage("stackMessage", `${formatNumber(value)} pushed onto the stack.`);
  }
  renderStack();
});
$("#stackPop").addEventListener("click", () => {
  if (!requireEngine()) return;
  if (!engine.stack_size()) setMessage("stackMessage", "The stack is empty; there is nothing to pop.", true);
  else {
    const value = engine.stack_value_at(engine.stack_size() - 1);
    engine.stack_pop();
    setMessage("stackMessage", `${formatNumber(value)} popped from the stack.`);
  }
  renderStack();
});
$("#stackPeek").addEventListener("click", () => {
  if (!requireEngine()) return;
  const size = engine.stack_size();
  setMessage("stackMessage", size ? `Top of stack: ${formatNumber(engine.stack_value_at(size - 1))}.` : "The stack is empty.", !size);
});

function renderQueue() {
  const size = engine.queue_size();
  const visual = $("#queueVisual");
  visual.replaceChildren();
  for (let i = 0; i < size; i += 1) {
    const item = document.createElement("div");
    item.className = "structure-item";
    item.textContent = formatNumber(engine.queue_value_at(i));
    item.setAttribute("aria-label", `${i === 0 ? "Front" : i === size - 1 ? "Rear" : "Queue"}: ${engine.queue_value_at(i)}`);
    visual.append(item);
  }
  if (!size) visual.innerHTML = '<div class="empty-structure">Your queue is empty.</div>';
  $("#queueSummary").textContent = `${size} item${size === 1 ? "" : "s"} · ${size ? "front to rear" : "empty"}`;
  $("#queueCapacityLabel").textContent = engine.queue_capacity();
  $("#queueCapacityInput").value = engine.queue_capacity();
}
$("#setQueueCapacity").addEventListener("click", () => {
  if (!requireEngine()) return;
  const capacity = Number($("#queueCapacityInput").value);
  if (!Number.isInteger(capacity) || !engine.queue_set_capacity(capacity)) {
    setMessage("queueMessage", "Capacity must be 1–12 and cannot be less than the current number of items.", true);
    return;
  }
  setMessage("queueMessage", `Queue capacity set to ${capacity}.`);
  renderQueue();
});
$("#queueEnqueue").addEventListener("click", () => {
  if (!requireEngine()) return;
  const input = $("#queueValue").value;
  const value = Number(input);
  if (input.trim() === "" || !Number.isFinite(value)) setMessage("queueMessage", "Enter a valid number to enqueue.", true);
  else if (!engine.queue_enqueue(value)) setMessage("queueMessage", "The queue is full. Dequeue an item or increase its capacity.", true);
  else {
    $("#queueValue").value = "";
    setMessage("queueMessage", `${formatNumber(value)} added to the rear of the queue.`);
  }
  renderQueue();
});
$("#queueDequeue").addEventListener("click", () => {
  if (!requireEngine()) return;
  const value = engine.queue_value_at(0);
  if (!engine.queue_dequeue()) setMessage("queueMessage", "The queue is empty; there is nothing to dequeue.", true);
  else setMessage("queueMessage", `${formatNumber(value)} removed from the front of the queue.`);
  renderQueue();
});

function renderList() {
  const size = engine.list_size();
  const visual = $("#linkedVisual");
  visual.replaceChildren();
  if (!size) {
    const empty = document.createElement("div");
    empty.className = "empty-structure";
    empty.textContent = "Your linked list is empty.";
    visual.append(empty);
  }
  for (let i = 0; i < size; i += 1) {
    const wrapper = document.createElement("div");
    wrapper.className = "node-wrap";
    const node = document.createElement("div");
    node.className = "node-box";
    node.textContent = formatNumber(engine.list_value_at(i));
    node.setAttribute("aria-label", `${i === 0 ? "Head " : i === size - 1 ? "Tail " : ""}node ${i + 1}: ${engine.list_value_at(i)}`);
    wrapper.append(node);
    if (i < size - 1) {
      const arrow = document.createElement("span");
      arrow.className = "node-arrow";
      arrow.textContent = engine.list_is_doubly() ? "↔" : "→";
      wrapper.append(arrow);
    }
    visual.append(wrapper);
  }
  $("#listSummary").textContent = `${size} node${size === 1 ? "" : "s"}`;
  $("#listSize").textContent = size;
  const doubly = engine.list_is_doubly();
  $("#listVisualTitle").textContent = doubly ? "Doubly linked list" : "Singly linked list";
  $("#listDirection").textContent = doubly ? "HEAD ↔ TAIL" : "HEAD → TAIL";
}
function handleListAction(action) {
  if (!requireEngine()) return;
  const valueText = $("#listValue").value.trim();
  const referenceText = $("#listReference").value.trim();
  const value = Number(valueText);
  const reference = Number(referenceText);
  let result = 0;
  let message = "";
  let error = false;
  if (action === "prepend" || action === "append") {
    if (!valueText || !Number.isFinite(value)) {
      message = "Enter a valid number for the new node.";
      error = true;
    } else {
      result = engine.list_add(value, action === "prepend" ? 1 : 0);
      message = result ? `${formatNumber(value)} added to the ${action === "prepend" ? "beginning" : "end"} of the list.` : "The list has reached its node capacity.";
      error = !result;
    }
  } else if (action === "before" || action === "after") {
    if (!valueText || !Number.isFinite(value) || !referenceText || !Number.isFinite(reference)) {
      message = "Enter both a new value and a reference value.";
      error = true;
    } else {
      result = engine.list_insert(value, reference, action === "before" ? 1 : 0);
      message = result === 1 ? `${formatNumber(value)} inserted ${action} ${formatNumber(reference)}.` : result === -1 ? "The list has reached its node capacity." : `Reference value ${formatNumber(reference)} was not found.`;
      error = result !== 1;
    }
  } else if (action === "first" || action === "last") {
    result = engine.list_remove(0, action === "first" ? 0 : 1);
    message = result ? `${action === "first" ? "First" : "Last"} node removed.` : "The list is empty.";
    error = !result;
  } else if (action === "value") {
    if (!valueText || !Number.isFinite(value)) {
      message = "Enter the value to delete.";
      error = true;
    } else {
      result = engine.list_remove(value, 2);
      message = result ? `${formatNumber(value)} deleted from the list.` : `${formatNumber(value)} was not found.`;
      error = !result;
    }
  } else if (action === "search") {
    if (!valueText || !Number.isFinite(value)) {
      message = "Enter a value to search for.";
      error = true;
    } else {
      result = engine.list_search(value);
      message = result ? `${formatNumber(value)} is in the list.` : `${formatNumber(value)} is not in the list.`;
      error = !result;
    }
  }
  setMessage("listMessage", message, error);
  renderList();
}

$("#checkBrackets").addEventListener("click", () => {
  if (!requireEngine()) return;
  clearFeedback("bracketMessage");
  const text = $("#bracketInput").value;
  const encoder = new TextEncoder();
  const bytes = encoder.encode(text);
  const pointer = engine.__heap_base.value;
  if (pointer + bytes.length >= engine.memory.buffer.byteLength) {
    setMessage("bracketMessage", "The expression is too long to check.", true);
    return;
  }
  new Uint8Array(engine.memory.buffer, pointer, bytes.length).set(bytes);
  const valid = engine.brackets_check(pointer, bytes.length);
  const rows = engine.brackets_rows();
  const trace = $("#bracketTrace");
  trace.replaceChildren();
  const visual = $("#bracketVisual");
  visual.replaceChildren();
  for (let row = 0; row < rows; row += 1) {
    const tr = document.createElement("tr");
    const character = document.createElement("td");
    character.textContent = String.fromCharCode(engine.brackets_character(row));
    const action = document.createElement("td");
    const actionCode = engine.brackets_action(row);
    action.textContent = actionCode === 1 ? "Push opening bracket" : actionCode === 2 ? "Match and pop" : "No matching opener";
    const stack = document.createElement("td");
    const depth = engine.brackets_depth(row);
    stack.textContent = depth ? Array.from({ length: depth }, (_, index) => String.fromCharCode(engine.brackets_stack_at(row, index))).join(" ") : "Empty";
    tr.append(character, action, stack);
    trace.append(tr);
    const chip = document.createElement("span");
    chip.className = "bracket-chip";
    chip.textContent = String.fromCharCode(engine.brackets_character(row));
    chip.title = `${action.textContent} · Stack: ${stack.textContent}`;
    visual.append(chip);
  }
  if (!rows) {
    const tr = document.createElement("tr");
    const td = document.createElement("td");
    td.colSpan = 3;
    td.className = "empty-cell";
    td.textContent = "No brackets were found in this expression.";
    tr.append(td);
    trace.append(tr);
    visual.textContent = "No brackets found";
  }
  setMessage("bracketMessage", valid ? "Balanced — every opening bracket has a matching closer." : "Not balanced — one or more brackets are mismatched or unclosed.", !valid);
});

function renderAllStructures() {
  if (!engine) return;
  renderStack();
  renderQueue();
  renderList();
}

$("#runBenchmark").addEventListener("click", () => {
  if (!requireEngine()) return;
  clearFeedback("benchMessage");
  const algorithm = Number($("#benchAlgorithm").value);
  const length = Number($("#benchSize").value);
  const order = Number($("#benchOrder").value);
  const allowedMaximum = algorithm === 1 ? 1000 : [0, 2].includes(algorithm) ? 2000 : 100000;
  if (length > allowedMaximum) {
    showFeedback("benchMessage", `${algorithmNames[algorithm]} is capped at ${formatNumber(allowedMaximum)} values to keep the experiment responsive.`);
    return;
  }
  $("#runBenchmark").disabled = true;
  $("#runBenchmark").textContent = "Running…";
  window.setTimeout(() => {
    try {
      const durations = [];
      let comparisons = 0;
      let moves = 0;
      for (let run = 0; run < 3; run += 1) {
        const started = performance.now();
        const success = engine.benchmark_run(length, algorithm, order, 42 + run * 101);
        durations.push(performance.now() - started);
        if (!success) throw new Error("The C++ engine rejected this benchmark configuration.");
        comparisons = engine.benchmark_comparisons();
        moves = engine.benchmark_moves();
      }
      const average = durations.reduce((sum, duration) => sum + duration, 0) / durations.length;
      $("#benchDescription").textContent = `${algorithmNames[algorithm]} · ${["random", "sorted", "reverse-sorted"][order]} input`;
      $("#benchTime").textContent = formatDuration(average);
      $("#benchComparisons").textContent = formatNumber(comparisons);
      $("#benchMoves").textContent = formatNumber(moves);
      $("#benchInputSize").textContent = formatNumber(length);
      renderBenchmarkBars(comparisons, moves);
      $("#benchRuns").textContent = "3 runs · average";
    } catch (error) {
      showFeedback("benchMessage", error.message);
    } finally {
      $("#runBenchmark").disabled = false;
      $("#runBenchmark").innerHTML = "Run experiment <span>→</span>";
    }
  }, 30);
});

function renderBenchmarkBars(comparisons, moves) {
  const chart = $("#benchmarkBars");
  chart.replaceChildren();
  const max = Math.max(comparisons, moves, 1);
  [["Comparisons", comparisons], ["Moves / swaps", moves]].forEach(([label, value]) => {
    const row = document.createElement("div");
    row.className = "benchmark-row";
    const name = document.createElement("span");
    name.textContent = label;
    const track = document.createElement("div");
    track.className = "benchmark-track";
    const fill = document.createElement("div");
    fill.className = "benchmark-fill";
    fill.style.width = `${Math.max(1, (value / max) * 100)}%`;
    track.append(fill);
    const count = document.createElement("strong");
    count.textContent = formatNumber(value);
    row.append(name, track, count);
    chart.append(row);
  });
}

loadEngine();
