#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <ws2tcpip.h>

#include <fstream>
#include <iostream>
#include <iterator>
#include <map>
#include <string>

namespace {
bool sendAll(SOCKET client, const std::string& data) {
  std::size_t sent = 0;
  while (sent < data.size()) {
    const int count = send(client, data.data() + sent, static_cast<int>(data.size() - sent), 0);
    if (count <= 0) return false;
    sent += static_cast<std::size_t>(count);
  }
  return true;
}

void respond(SOCKET client, const std::string& status, const std::string& type,
             const std::string& body) {
  const std::string header = "HTTP/1.1 " + status + "\r\n"
    "Content-Type: " + type + "\r\n"
    "Content-Length: " + std::to_string(body.size()) + "\r\n"
    "Cache-Control: no-store\r\n"
    "X-Content-Type-Options: nosniff\r\n"
    "Connection: close\r\n\r\n";
  sendAll(client, header);
  sendAll(client, body);
}

void serve(SOCKET client) {
  char request[8192] = {};
  const int received = recv(client, request, sizeof(request) - 1, 0);
  if (received <= 0) return;

  std::string firstLine(request, static_cast<std::size_t>(received));
  const std::size_t lineEnd = firstLine.find("\r\n");
  if (lineEnd != std::string::npos) firstLine.resize(lineEnd);
  const std::size_t firstSpace = firstLine.find(' ');
  const std::size_t secondSpace = firstSpace == std::string::npos
    ? std::string::npos : firstLine.find(' ', firstSpace + 1);
  if (firstSpace == std::string::npos || secondSpace == std::string::npos ||
      firstLine.substr(0, firstSpace) != "GET") {
    respond(client, "405 Method Not Allowed", "text/plain; charset=utf-8", "Only GET is supported.");
    return;
  }

  std::string path = firstLine.substr(firstSpace + 1, secondSpace - firstSpace - 1);
  const std::size_t query = path.find('?');
  if (query != std::string::npos) path.resize(query);
  if (path == "/") path = "/index.html";

  static const std::map<std::string, std::pair<std::string, std::string>> files = {
    {"/index.html", {"index.html", "text/html; charset=utf-8"}},
    {"/style.css", {"style.css", "text/css; charset=utf-8"}},
    {"/script.js", {"script.js", "text/javascript; charset=utf-8"}},
    {"/algorithm-explorer.wasm", {"algorithm-explorer.wasm", "application/wasm"}}
  };
  const auto found = files.find(path);
  if (found == files.end()) {
    respond(client, "404 Not Found", "text/plain; charset=utf-8", "Page not found.");
    return;
  }

  std::ifstream file(found->second.first, std::ios::binary);
  if (!file) {
    respond(client, "500 Internal Server Error", "text/plain; charset=utf-8",
            "A required application file is missing. Run build.bat and restart the server.");
    return;
  }
  const std::string body((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
  respond(client, "200 OK", found->second.second, body);
}
}

int main() {
  WSADATA data{};
  if (WSAStartup(MAKEWORD(2, 2), &data) != 0) {
    std::cerr << "Could not initialize Windows networking.\n";
    return 1;
  }

  SOCKET listener = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
  if (listener == INVALID_SOCKET) {
    std::cerr << "Could not create the local web server socket.\n";
    WSACleanup();
    return 1;
  }

  sockaddr_in address{};
  address.sin_family = AF_INET;
  address.sin_port = htons(4173);
  inet_pton(AF_INET, "127.0.0.1", &address.sin_addr);
  if (bind(listener, reinterpret_cast<sockaddr*>(&address), sizeof(address)) == SOCKET_ERROR ||
      listen(listener, SOMAXCONN) == SOCKET_ERROR) {
    std::cerr << "Could not start the server on http://127.0.0.1:4173. "
                 "Check whether that port is already in use.\n";
    closesocket(listener);
    WSACleanup();
    return 1;
  }

  std::cout << "Algorithm Explorer is running at http://127.0.0.1:4173\n"
               "Keep this window open while you use the application. Press Ctrl+C to stop.\n";
  for (;;) {
    SOCKET client = accept(listener, nullptr, nullptr);
    if (client == INVALID_SOCKET) continue;
    serve(client);
    closesocket(client);
  }
}
